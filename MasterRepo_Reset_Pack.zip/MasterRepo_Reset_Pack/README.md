# MasterRepo Reset Pack

This pack resets `MasterRepo` to the current agreed direction.

## Reset Intent

MasterRepo is the standalone NovaForge game repo.
It contains only the game, the engine, and the game-specific editor.
It does not absorb Atlas Suite, AtlasAI broker flows, generic workspace tooling, or cross-repo shell systems.

## What This Pack Does

- rewrites the roadmap around the current phase order
- locks repo boundaries
- adds a phase-by-phase execution pack
- adds a gap matrix
- adds a definition of done
- adds a project manifest stub for project-local pathing

## Current Phase Order

1. Phase 0: bootstrap and bootable editor/game skeleton
2. Phase 1: dev world only
3. Phase 2: voxel runtime only
4. Phase 3: first interaction loop only

## Apply Strategy

1. Merge the `Docs/Game/` files from this pack into the repo.
2. Add `Config/novaforge.project.json`.
3. Replace older roadmap/task docs where they conflict with this pack.
4. Keep the existing compile-safe code scaffolds unless a file directly conflicts with the locked repo boundary.
5. Treat this pack as the new planning baseline before more code generation.
